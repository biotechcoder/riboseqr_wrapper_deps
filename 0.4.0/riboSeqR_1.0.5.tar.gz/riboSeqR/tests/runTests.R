BiocGenerics:::testPackage("riboSeqR")
